echo " "
printf "\e[1;31mDEVELOPER\e[0m\n"
echo " "  
printf "\e[1;33mADEEB PULATH \e[0m\e[1;92m[ADP]\e[0m\n"

echo " " 
 
printf "Instagram ID @m_r._.hacker\n"
  
 
