<?php
$rhversion = "1.0.0";
$white = "\e[97m";
$black = "\e[30m\e[1m";
$yellow = "\e[93m";
$orange = "\e[38;5;208m";
$blue   = "\e[34m";
$lblue  = "\e[36m";
$cln    = "\e[0m";
$green  = "\e[92m";
$fgreen = "\e[32m";
$red    = "\e[91m";
$magenta = "\e[35m";
$bluebg = "\e[44m";
$lbluebg = "\e[106m";
$greenbg = "\e[42m";
$lgreenbg = "\e[102m";
$yellowbg = "\e[43m";
$lyellowbg = "\e[103m";
$redbg = "\e[101m";
$grey = "\e[37m";
$cyan = "\e[36m";
$bold   = "\e[1m";
function ADP_banner(){
  echo "\e[91;1m
             Tool For\e[36m Information Gathering\e[91m And\e[32m Vulnerability Scanning\e[91m
                                     _      ____    ____  
                                    / \    |  _ \  |  _ \ 
                                   / _ \   | | | | | |_) |
                                  / ___ \  | |_| | |  __/ 
                                 /_/   \_\ |____/  |_|    
\e[32m
  \n";
}
?>
