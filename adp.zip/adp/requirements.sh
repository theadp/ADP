#!/bin/bash
echo ""
echo ""
echo ""
apt install figlet -y
echo ""
echo ""
echo ""
figlet "ADP"
echo "Connecting to server...."
sleep 0.5
echo -e "\e[4;95m Installing Dependencies.... \e[0m"
sleep 0.5
echo -e "\e[1;96m"
apt install python
apt install php
wget -O $PREFIX/share/figlet/ASCII-Shadow.flf https://raw.githubusercontent.com/xero/figlet-fonts/master/ANSI%20Shadow.flf
touch plugins.installed
echo -e "\e[3;94m Dependencies Installed!"
sleep 0.5
echo -e "\e[3;94m start the tool!" 
sleep 0.5
