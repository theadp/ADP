#This Page is  created by adeeb pulath
#Noobs Dont edit my codes
#Give me Credits before you edit my Codes
 
menu()
{
	clear                             
           printf " \e[33;1m            ____    ____      \e[0m\n"   
          printf " \e[33;1m     / \    |  _ \  |  _ \    \e[0m\n" 
         printf " \e[32;1m     / _ \   | | | | | |_) |  \e[0m\n"  
        printf " \e[32;1m     / ___ \  | |_| | |  __/   \e[0m\n"
       printf " \e[33;1m     /_/   \_\ |____/  |_|   1.0  \e[0m\n"                                      
        printf "\n"

	printf   "\e[1;92m    [\e[0m\e[1;77m01\e[0m\e[1;92m]\e[0m\e[1;33mPhishing Tools \e[0m\n"
	printf   "\e[1;92m    [\e[0m\e[1;77m02\e[0m\e[1;92m]\e[0m\e[1;33mDdos Attack\e[0m\n"
	printf   "\e[1;92m    [\e[0m\e[1;77m03\e[0m\e[1;92m]\e[0m\e[1;33mInformation Gathering\e[0m\n"
	printf   "\e[1;92m    [\e[0m\e[1;77m04\e[0m\e[1;92m]\e[0m\e[1;33mAbout the Developer\e[0m\n"	
	printf   "\e[1;92m    [\e[0m\e[1;77m05\e[0m\e[1;92m]\e[0m\e[1;33mExit Tool\e[0m\n"
	printf "\n\e[1;92mUse Tool For Education Purposes Only\e[0m\n"
	printf "\n"
	read -p $'\e[1;92m[\e[0m\e[1;77m>\e[0m\e[1;92m] Select a Tool: \e[0m' option
	
	if [[ $option == 1 || $option == 01 ]]; then
bash adp1/adpphish.sh

elif [[ $option == 2 || $option == 02 ]]; then
printf "Go and Type This Commands And do the attack😊\n"
chmod +x adp.py && python3 adp.py -h 

elif [[ $option == 3 || $option == 03 ]]; then
cd  adp3 && php adp.php



elif [[ $option == 4 || $option == 04 ]]; then
bash about.sh

elif [[ $option == 5 || $option == 05 ]]; then
printf "Tool Exited...😊\n"
exit

else
printf "\e[1;93m [!] Invalid option!\e[0m\n"
sleep 1
clear
menu
fi
	}
menu
